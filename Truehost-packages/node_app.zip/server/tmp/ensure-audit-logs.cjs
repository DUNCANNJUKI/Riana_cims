const path = require('node:path');
const mysql = require('mysql2/promise');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env.local') });

async function run() {
  const connection = await mysql.createConnection({
    host: process.env.DATABASE_HOST || '127.0.0.1',
    port: Number(process.env.DATABASE_PORT || 3306),
    user: process.env.DATABASE_USER || 'root',
    password: process.env.DATABASE_PASSWORD || '',
    database: process.env.DATABASE_NAME || 'riana_cims',
    multipleStatements: true,
  });
  try {
    await connection.query(`CREATE TABLE IF NOT EXISTS audit_logs (
      id VARCHAR(36) PRIMARY KEY,
      event_uuid VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NULL,
      impersonator_user_id VARCHAR(36) NULL,
      action VARCHAR(120) NOT NULL,
      category VARCHAR(60) NOT NULL DEFAULT 'system',
      module VARCHAR(80) NOT NULL,
      entity_type VARCHAR(80) NULL,
      entity_id VARCHAR(100) NULL,
      description VARCHAR(1000) NULL,
      old_values JSON NULL,
      new_values JSON NULL,
      metadata JSON NULL,
      ip_address VARCHAR(45) NULL,
      user_agent TEXT NULL,
      device VARCHAR(255) NULL,
      session_id VARCHAR(120) NULL,
      request_id VARCHAR(80) NULL,
      route VARCHAR(255) NULL,
      http_method VARCHAR(12) NULL,
      status ENUM('success','failure','denied') NOT NULL DEFAULT 'success',
      severity ENUM('info','notice','warning','critical') NOT NULL DEFAULT 'info',
      integrity_hash CHAR(64) NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_audit_logs_user_created (user_id,created_at),
      INDEX idx_audit_logs_action (action),
      INDEX idx_audit_logs_module_created (module,created_at),
      INDEX idx_audit_logs_entity (entity_type,entity_id),
      INDEX idx_audit_logs_created (created_at),
      INDEX idx_audit_logs_severity (severity),
      INDEX idx_audit_logs_status (status),
      INDEX idx_audit_logs_ip (ip_address),
      UNIQUE KEY uq_audit_event_uuid (event_uuid),
      CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE SET NULL,
      CONSTRAINT fk_audit_logs_impersonator FOREIGN KEY (impersonator_user_id) REFERENCES user_profiles(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
    await connection.query(`CREATE TABLE IF NOT EXISTS migration_history (
      migration_id VARCHAR(100) PRIMARY KEY,
      description VARCHAR(255) NOT NULL,
      applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`);
    await connection.query(
      `INSERT INTO migration_history (migration_id, description) VALUES (?, ?) ON DUPLICATE KEY UPDATE description=VALUES(description)`,
      ['20260710_chat_audit_logging_audit_logs_hotfix', 'Created audit_logs table from saved 20260710 chat audit migration to unblock login']
    );
    const [tables] = await connection.query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'audit_logs'");
    const [indexes] = await connection.query("SHOW INDEX FROM audit_logs");
    console.log(JSON.stringify({ audit_logs_exists: tables.length === 1, index_count: indexes.length }, null, 2));
  } finally {
    await connection.end();
  }
}

run().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});