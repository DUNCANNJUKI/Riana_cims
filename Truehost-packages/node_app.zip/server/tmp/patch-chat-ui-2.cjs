﻿const fs = require('fs');
const path = require('path');

const chatPath = path.join(process.cwd(), 'src', 'components', 'chat', 'ChatModule.tsx');
let chat = fs.readFileSync(chatPath, 'utf8');
const replaceLiteral = (from, to) => {
  if (!chat.includes(from)) throw new Error(`Missing ChatModule literal:\n${from}`);
  chat = chat.replace(from, to);
};
const replaceRegex = (pattern, to, label) => {
  if (!pattern.test(chat)) throw new Error(`Missing ChatModule regex: ${label}`);
  chat = chat.replace(pattern, to);
};

replaceLiteral(
`  const activeUser = users.find(u => u.id === activeChatUserId);
  const activeCallParticipantIds = activeCall
`,
`  const visibleUsers = users.filter(user => user.id !== currentUser.id);
  const activeUser = visibleUsers.find(u => u.id === activeChatUserId);
  const activeCallParticipantIds = activeCall
`);

replaceLiteral(
`  const selectedCallTargets = activeChatUserId
    ? Array.from(new Set([activeChatUserId, ...selectedCallParticipantIds])).filter(id => id && id !== currentUser.id)
    : [];

  const filteredUsers = users.filter(u => {
`,
`  const selectedCallTargets = activeChatUserId
    ? Array.from(new Set([activeChatUserId, ...selectedCallParticipantIds])).filter(id => id && id !== currentUser.id && visibleUsers.some(user => user.id === id))
    : [];

  const filteredUsers = visibleUsers.filter(u => {
`);

replaceLiteral(
`  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
`,
`  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (!activeChatUserId) return;
    const canChatWithActiveUser = activeChatUserId !== currentUser.id && users.some(user => user.id === activeChatUserId && user.id !== currentUser.id);
    if (!canChatWithActiveUser) {
      setActiveChatUserId(null);
      setSelectedCallParticipantIds([]);
    }
  }, [activeChatUserId, currentUser.id, users, setActiveChatUserId]);
`);

replaceRegex(
/    if \(\(!inputText\.trim\(\) && !selectedFile\) \|\| !activeChatUserId \|\| isSending\) return;\r?\n/,
`    if ((!inputText.trim() && !selectedFile) || !activeChatUserId || isSending) return;
    if (activeChatUserId === currentUser.id) {
      toast({ title: "Select a colleague", description: "You cannot send a chat message to your own account.", variant: "destructive" });
      setActiveChatUserId(null);
      return;
    }
`,
'handleSend guard'
);

replaceLiteral(
`    <div className="flex h-full w-full max-w-4xl overflow-hidden rounded-2xl border shadow-2xl glass-card">
      <div className={cn("flex flex-col border-r bg-background/20 transition-all duration-300", isSidebarOpen ? "w-[320px]" : "w-0 overflow-hidden")}>
        <div className="space-y-4 border-b p-5">
`,
`    <div className="flex h-[min(760px,calc(100vh-5rem))] min-h-[520px] w-full max-w-5xl overflow-hidden rounded-xl border bg-background shadow-2xl glass-card">
      <div className={cn("flex flex-col border-r bg-background transition-all duration-300", isSidebarOpen ? "w-[310px]" : "w-0 overflow-hidden")}>
        <div className="space-y-3 border-b p-4">
`);

replaceLiteral(
`          <div className="space-y-1 px-1 py-3">
            {filteredUsers.length > 0 ? filteredUsers.map(user => (
              <button key={user.id} onClick={() => setActiveChatUserId(user.id)} className={cn("chat-sidebar-item group flex w-[calc(100%-16px)] items-center gap-3 p-3 text-left", activeChatUserId === user.id && "chat-sidebar-active")}>
`,
`          <div className="space-y-1 px-2 py-3">
            {filteredUsers.length > 0 ? filteredUsers.map(user => (
              <button key={user.id} onClick={() => { setActiveChatUserId(user.id); setSelectedCallParticipantIds([]); }} className={cn("chat-sidebar-item group flex w-full items-center gap-3 p-3 text-left", activeChatUserId === user.id && "chat-sidebar-active")}>
`);

replaceLiteral(
`      <div className="relative flex flex-1 flex-col bg-muted/30 dark:bg-background/20">
`,
`      <div className="relative flex min-w-0 flex-1 flex-col bg-muted/20 dark:bg-background/20">
`);

replaceLiteral(
`            <header className="z-10 flex items-center justify-between border-b bg-background/80 px-6 py-4 backdrop-blur-md">
`,
`            <header className="z-10 flex items-center justify-between border-b bg-background/95 px-4 py-3 backdrop-blur-md sm:px-5">
`);

replaceLiteral(
`                    {users.filter(user => user.id !== currentUser.id && user.id !== activeChatUserId).slice(0, 12).map(user => (
`,
`                    {visibleUsers.filter(user => user.id !== activeChatUserId).slice(0, 12).map(user => (
`);

replaceLiteral(
`            <ScrollArea className="flex-1 px-6 scroll-smooth">
              <div className="space-y-6 py-6">
                {messages.map((msg, index) => {
`,
`            <ScrollArea className="flex-1 px-4 scroll-smooth sm:px-6">
              <div className="space-y-5 py-5">
                {messages.length === 0 && (
                  <div className="flex min-h-[260px] flex-col items-center justify-center rounded-lg border border-dashed bg-background/60 px-6 text-center text-muted-foreground">
                    <MessageSquare className="mb-3 h-9 w-9 text-primary/60" />
                    <p className="text-sm font-semibold text-foreground">No messages yet</p>
                    <p className="mt-1 max-w-sm text-xs">Start the conversation with {formatUserName(activeUser)}.</p>
                  </div>
                )}
                {messages.map((msg, index) => {
`);

replaceLiteral(
`                        <div className={cn("group max-w-[80%] px-4 py-3 shadow-md relative", isMe ? "chat-bubble-me text-white" : "chat-bubble-other text-slate-900")}>
`,
`                        <div className={cn("group relative max-w-[min(78%,36rem)] px-4 py-3 shadow-sm", isMe ? "chat-bubble-me text-white" : "chat-bubble-other text-card-foreground")}>
`);

replaceLiteral(
`                          <div className={cn("mt-1.5 flex items-center justify-end gap-1.5 text-[10px]", isMe ? "text-white/80" : "text-slate-500")}>
`,
`                          <div className={cn("mt-1.5 flex items-center justify-end gap-1.5 text-[10px]", isMe ? "text-white/80" : "text-muted-foreground")}>
`);

replaceLiteral(
`            <div className="border-t bg-background/80 p-4 backdrop-blur-md sm:p-6">
`,
`            <div className="border-t bg-background/95 p-3 backdrop-blur-md sm:p-4">
`);

replaceLiteral(
`              <form onSubmit={handleSend} className="flex items-end gap-3">
`,
`              <form onSubmit={handleSend} className="flex items-center gap-2">
`);

let attachChanged = false;
let emojiChanged = false;
let inputChanged = false;
let submitChanged = false;
chat = chat.split(/\r?\n/).map(line => {
  if (line.includes('title="Attach file"') && line.includes('h-12 w-12 rounded-2xl')) {
    attachChanged = true;
    return '                <Button type="button" variant="outline" size="icon" className="h-10 w-10 shrink-0 rounded-lg" onClick={() => fileInputRef.current?.click()} title="Attach file" disabled={Boolean(editingMessage)}><Paperclip className="h-4 w-4" /></Button>';
  }
  if (line.includes('title="Insert emoji"') && line.includes('h-12 w-12 rounded-2xl')) {
    emojiChanged = true;
    return '                    <Button type="button" variant="outline" size="icon" className="h-10 w-10 shrink-0 rounded-lg" title="Insert emoji"><SmilePlus className="h-4 w-4" /></Button>';
  }
  if (line.includes('<div className="flex-1 rounded-2xl border border-primary/10')) {
    inputChanged = true;
    return '                <div className="min-w-0 flex-1 rounded-lg border border-primary/10 bg-muted/30 p-1 transition-all focus-within:border-primary/40 focus-within:ring-4 focus-within:ring-primary/5">';
  }
  if (line.includes('<Input placeholder="Message..."')) {
    return '                  <Input placeholder="Write a message..." value={inputText} onChange={(event) => { const nextValue = event.target.value; setInputText(nextValue); if (!activeChatUserId || activeChatUserId === currentUser.id) return; if (!inputText && nextValue) void setTyping(activeChatUserId, true); if (typingTimerRef.current) window.clearTimeout(typingTimerRef.current); typingTimerRef.current = window.setTimeout(() => void setTyping(activeChatUserId, false), 1200); }} onBlur={() => activeChatUserId && activeChatUserId !== currentUser.id && void setTyping(activeChatUserId, false)} className="h-9 border-none bg-transparent px-3 shadow-none focus-visible:ring-0 focus-visible:ring-offset-0" autoFocus />';
  }
  if (line.includes('type="submit"') && line.includes('h-12 w-12 flex-shrink-0 rounded-2xl')) {
    submitChanged = true;
    return '                <Button type="submit" size="icon" className="h-10 w-10 flex-shrink-0 rounded-lg gradient-primary shadow-riana" disabled={isSending || activeChatUserId === currentUser.id || (!inputText.trim() && !selectedFile)}>{isSending ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : <Send className="h-4 w-4" />}</Button>';
  }
  return line;
}).join('\n');
if (!attachChanged || !emojiChanged || !inputChanged || !submitChanged) throw new Error(`Footer patch incomplete: ${JSON.stringify({ attachChanged, emojiChanged, inputChanged, submitChanged })}`);

fs.writeFileSync(chatPath, chat, 'utf8');

const cssPath = path.join(process.cwd(), 'src', 'index.css');
let css = fs.readFileSync(cssPath, 'utf8');
const cssFrom = `  .glass-card {
    background: rgba(255, 255, 255, 0.7);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.2);
  }

  .dark .glass-card {
    background: rgba(15, 23, 42, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  .chat-bubble-me {
    @apply rounded-2xl rounded-tr-sm bg-primary text-white shadow-md;
    background-color: hsl(var(--primary)) !important;
  }

  .chat-bubble-other {
    @apply rounded-2xl rounded-tl-sm bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 shadow-sm;
  }

  .chat-sidebar-item {
    @apply relative mx-2 mb-1 rounded-xl transition-all duration-300 border border-transparent hover:bg-black/5 dark:hover:bg-white/5;
  }

  .chat-sidebar-active {
    @apply bg-primary/10 border-r-4 border-primary shadow-sm;
  }
`;
const cssTo = `  .glass-card {
    background: hsl(var(--background));
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid hsl(var(--border));
  }

  .dark .glass-card {
    background: hsl(var(--background));
    border-color: hsl(var(--border));
  }

  .chat-bubble-me {
    @apply rounded-xl rounded-br-sm bg-primary text-white shadow-sm;
    background-color: hsl(var(--primary)) !important;
  }

  .chat-bubble-other {
    @apply rounded-xl rounded-bl-sm border border-border bg-card text-card-foreground shadow-sm;
  }

  .chat-sidebar-item {
    @apply relative mb-1 rounded-lg border border-transparent transition-colors duration-200 hover:bg-muted;
  }

  .chat-sidebar-active {
    @apply border-primary bg-primary/10 shadow-sm;
  }
`;
if (!css.includes(cssFrom)) throw new Error('Missing chat CSS block');
css = css.replace(cssFrom, cssTo);
fs.writeFileSync(cssPath, css, 'utf8');
console.log('patched chat UI and CSS');
