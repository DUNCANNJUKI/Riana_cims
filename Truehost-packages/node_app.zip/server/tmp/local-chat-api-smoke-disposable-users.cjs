﻿const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const envPath = path.join(process.cwd(), '.env.local');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}
const first = (...names) => names.map(name => process.env[name]).find(value => value !== undefined && value !== null && value !== '');
const config = {
  host: first('DATABASE_HOST', 'DB_HOST') || 'localhost',
  port: Number(first('DATABASE_PORT', 'DB_PORT') || 3306),
  user: first('DATABASE_USER', 'DB_USER') || 'root',
  password: first('DATABASE_PASSWORD', 'DB_PASSWORD', 'DB_PASS') || '',
  database: first('DATABASE_NAME', 'DB_NAME') || 'riana_cims',
};
const safeJson = async (response) => {
  const text = await response.text();
  try { return JSON.parse(text); } catch { return { raw: text }; }
};
async function publicApi(method, endpoint, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`http://localhost:8081/api${endpoint}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await safeJson(response);
  if (!response.ok) throw new Error(`${method} ${endpoint} failed ${response.status}: ${JSON.stringify(data)}`);
  return data;
}
async function cleanup(conn, ids) {
  if (!ids.length) return;
  const placeholders = ids.map(() => '?').join(',');
  await conn.query(`DELETE FROM user_profiles WHERE id IN (${placeholders})`, ids);
}
(async () => {
  const runId = Date.now();
  const sender = { id: uuidv4(), email: `local-qa-chat-sender-${runId}@example.test`, first: 'Local QA', last: 'Sender' };
  const recipient = { id: uuidv4(), email: `local-qa-chat-recipient-${runId}@example.test`, first: 'Local QA', last: 'Recipient' };
  const password = `LocalQa!${runId}`;
  const passwordHash = await bcrypt.hash(password, 10);
  const conn = await mysql.createConnection(config);
  const ids = [sender.id, recipient.id];
  try {
    await cleanup(conn, ids);
    await conn.query(
      `INSERT INTO user_profiles (id,email,password,first_name,last_name,role,designation,first_login,is_active,two_factor_enabled,session_version)
       VALUES (?,?,?,?,?,'User','Local QA',FALSE,TRUE,FALSE,0),(?,?,?,?,?,'User','Local QA',FALSE,TRUE,FALSE,0)`,
      [sender.id, sender.email, passwordHash, sender.first, sender.last, recipient.id, recipient.email, passwordHash, recipient.first, recipient.last],
    );
    const login = await publicApi('POST', '/auth/login', { email: sender.email, password });
    if (!login.token) throw new Error(`Login did not return token: ${JSON.stringify(login)}`);
    const chatUsers = await publicApi('GET', '/chat/users', undefined, login.token);
    const recipientVisible = Array.isArray(chatUsers) && chatUsers.some(user => user.id === recipient.id);
    const message = await publicApi('POST', '/chat/messages', { receiver_id: recipient.id, content: `LOCAL QA chat smoke ${new Date().toISOString()}` }, login.token);
    await publicApi('POST', `/chat/messages/${message.id}/delete-for-everyone`, { reason: 'Local QA cleanup after smoke test.' }, login.token);
    const call = await publicApi('POST', '/chat/calls', { receiver_id: recipient.id, receiver_ids: [recipient.id], call_type: 'audio' }, login.token);
    await publicApi('PATCH', `/chat/calls/${call.id}`, { status: 'ended' }, login.token);
    const [statusRows] = await conn.query('SELECT COUNT(*) AS count FROM message_recipient_status WHERE message_id IN (?,?)', [message.id, call.id]);
    const [participantRows] = await conn.query('SELECT COUNT(*) AS count FROM call_participants WHERE call_id = ?', [call.id]);
    console.log(JSON.stringify({
      result: 'local disposable-user API smoke test passed',
      recipientVisible,
      chatUsers: Array.isArray(chatUsers) ? chatUsers.length : null,
      messageId: message.id,
      callId: call.id,
      recipientStatusRows: Number(statusRows[0].count || 0),
      callParticipantRows: Number(participantRows[0].count || 0),
    }, null, 2));
  } finally {
    await cleanup(conn, ids);
    await conn.end();
  }
})().catch(error => { console.error(error); process.exit(1); });
