﻿const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const envPath = path.join(__dirname, '..', '..', '.env.local');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}
const config = {
  host: process.env.DB_HOST || process.env.MYSQL_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || process.env.MYSQL_PORT || 3306),
  user: process.env.DB_USER || process.env.MYSQL_USER || 'root',
  password: process.env.DB_PASSWORD || process.env.MYSQL_PASSWORD || '',
  database: process.env.DB_NAME || process.env.MYSQL_DATABASE || 'riana_cims',
  multipleStatements: false,
};
const wanted = ['messages','user_profiles','message_edit_history','message_reactions','message_user_deletions','message_recipient_status','call_participants','chat_call_signals','audit_logs'];
(async () => {
  const conn = await mysql.createConnection(config);
  const [db] = await conn.query('SELECT DATABASE() AS db, VERSION() AS version');
  console.log('DATABASE', JSON.stringify(db[0]));
  const [tables] = await conn.query(`SELECT TABLE_NAME, ENGINE, TABLE_COLLATION FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (${wanted.map(() => '?').join(',')}) ORDER BY TABLE_NAME`, wanted);
  console.log('TABLES', JSON.stringify(tables, null, 2));
  const [cols] = await conn.query(`SELECT TABLE_NAME,COLUMN_NAME,COLUMN_TYPE,IS_NULLABLE,COLUMN_DEFAULT,CHARACTER_SET_NAME,COLLATION_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (${wanted.map(() => '?').join(',')}) AND COLUMN_NAME IN ('id','sender_id','receiver_id','message_id','user_id','edited_by','receiver_ids','content_hash') ORDER BY TABLE_NAME,ORDINAL_POSITION`, wanted);
  console.log('COLUMNS', JSON.stringify(cols, null, 2));
  await conn.end();
})().catch(err => { console.error(err); process.exit(1); });
