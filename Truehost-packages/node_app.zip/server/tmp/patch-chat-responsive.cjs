﻿const fs = require('fs');
const path = require('path');
const chatPath = path.join(process.cwd(), 'src', 'components', 'chat', 'ChatModule.tsx');
let chat = fs.readFileSync(chatPath, 'utf8');
const replace = (from, to, label) => {
  if (!chat.includes(from)) throw new Error(`Missing ${label}`);
  chat = chat.replace(from, to);
};
replace(
`    <div className="flex h-[min(760px,calc(100vh-5rem))] min-h-[520px] w-full max-w-5xl overflow-hidden rounded-xl border bg-background shadow-2xl glass-card">
      <div className={cn("flex flex-col border-r bg-background transition-all duration-300", isSidebarOpen ? "w-[310px]" : "w-0 overflow-hidden")}>
`,
`    <div className="flex h-[min(760px,calc(100vh-5rem))] min-h-[420px] w-full max-w-5xl overflow-hidden rounded-xl border bg-background shadow-2xl glass-card sm:min-h-[520px]">
      <div className={cn("flex flex-col border-r bg-background transition-all duration-300", isSidebarOpen ? "w-full md:w-[310px]" : "w-0 overflow-hidden")}>
`,
'chat root/sidebar classes'
);
replace(
`              <button key={user.id} onClick={() => { setActiveChatUserId(user.id); setSelectedCallParticipantIds([]); }} className={cn("chat-sidebar-item group flex w-full items-center gap-3 p-3 text-left", activeChatUserId === user.id && "chat-sidebar-active")}>
`,
`              <button key={user.id} onClick={() => { setActiveChatUserId(user.id); setSelectedCallParticipantIds([]); if (typeof window !== "undefined" && window.innerWidth < 768) setIsSidebarOpen(false); }} className={cn("chat-sidebar-item group flex w-full items-center gap-3 p-3 text-left", activeChatUserId === user.id && "chat-sidebar-active")}>
`,
'user selection mobile sidebar close'
);
replace(
`      <div className="relative flex min-w-0 flex-1 flex-col bg-muted/20 dark:bg-background/20">
`,
`      <div className={cn("relative min-w-0 flex-1 flex-col bg-muted/20 dark:bg-background/20", isSidebarOpen ? "hidden md:flex" : "flex")}>
`,
'main pane mobile visibility'
);
fs.writeFileSync(chatPath, chat, 'utf8');

const headerPath = path.join(process.cwd(), 'src', 'components', 'layout', 'Header.tsx');
let header = fs.readFileSync(headerPath, 'utf8');
const headerReplace = (from, to, label) => {
  if (!header.includes(from)) throw new Error(`Missing ${label}`);
  header = header.replace(from, to);
};
headerReplace(
`              title="Open Chat"
`,
`              title="Open Chat"
              aria-label="Open messages"
`,
'chat button aria label'
);
headerReplace(
`        <div className="fixed inset-x-2 bottom-2 z-50 h-[min(600px,calc(100dvh-80px))] animate-in slide-in-from-bottom-5 sm:inset-x-auto sm:bottom-4 sm:right-4 sm:w-[90vw] sm:max-w-[400px] md:max-w-4xl">
`,
`        <div className="fixed inset-x-2 bottom-2 z-50 h-[min(680px,calc(100dvh-80px))] animate-in slide-in-from-bottom-5 sm:inset-x-4 sm:bottom-4 sm:h-[min(720px,calc(100dvh-96px))] md:left-auto md:right-4 md:w-[min(92vw,1100px)]">
`,
'chat popup wrapper'
);
fs.writeFileSync(headerPath, header, 'utf8');
console.log('patched chat responsive wrapper');
