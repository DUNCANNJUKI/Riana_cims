﻿const fs = require('fs');
const path = require('path');
const files = [
  path.join(process.cwd(), 'hosting', 'Mysql_host', 'live_updates', '20260710_profile_avatar_chat_messages.sql'),
  path.join(process.cwd(), 'Truehost-packages', 'LIVE_DB_UPDATE_20260710.sql'),
];
const marker = `INSERT INTO migration_history (migration_id, description)
VALUES ('20260710_chat_audit_logging', 'Adds chat editing, reactions, per-user deletion, recipient read status, and central audit logs')
ON DUPLICATE KEY UPDATE description = VALUES(description);
`;
const insert = `${marker}
INSERT INTO migration_history (migration_id, description)
VALUES ('20260710_chat_support_tables_hotfix', 'Ensures chat edit, reaction, deletion, and recipient delivery-status tables exist for message sending')
ON DUPLICATE KEY UPDATE description = VALUES(description);
`;
for (const file of files) {
  let sql = fs.readFileSync(file, 'utf8');
  if (!sql.includes("20260710_chat_support_tables_hotfix")) {
    if (!sql.includes(marker)) throw new Error(`Missing chat audit marker in ${file}`);
    sql = sql.replace(marker, insert);
  }
  sql = sql.replace(
    "SHOW INDEX FROM message_reactions;",
    "SHOW INDEX FROM message_reactions;\nSHOW INDEX FROM message_recipient_status;"
  );
  fs.writeFileSync(file, sql, 'utf8');
  console.log(`updated ${path.relative(process.cwd(), file)}`);
}
