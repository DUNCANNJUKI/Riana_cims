﻿const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const envPath = path.join(__dirname, '..', '..', '.env.local');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}
const config = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'riana_cims',
};
(async () => {
  const conn = await mysql.createConnection(config);
  for (const table of ['user_profiles','messages','audit_logs']) {
    const [createRows] = await conn.query(`SHOW CREATE TABLE \`${table}\``);
    console.log(`--- ${table} ---`);
    console.log(createRows[0]['Create Table']);
    const [indexes] = await conn.query(`SHOW INDEX FROM \`${table}\``);
    console.log(JSON.stringify(indexes.map(i => ({Key_name:i.Key_name, Column_name:i.Column_name, Non_unique:i.Non_unique, Seq_in_index:i.Seq_in_index})), null, 2));
  }
  await conn.end();
})().catch(err => { console.error(err); process.exit(1); });
