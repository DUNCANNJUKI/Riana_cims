﻿const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const envPath = path.join(process.cwd(), '.env.local');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}
const first = (...names) => names.map(name => process.env[name]).find(value => value !== undefined && value !== null && value !== '');
const config = {
  host: first('DATABASE_HOST', 'DB_HOST') || 'localhost',
  port: Number(first('DATABASE_PORT', 'DB_PORT') || 3306),
  user: first('DATABASE_USER', 'DB_USER') || 'root',
  password: first('DATABASE_PASSWORD', 'DB_PASSWORD', 'DB_PASS') || '',
  database: first('DATABASE_NAME', 'DB_NAME') || 'riana_cims',
  multipleStatements: false,
};
const wantedTables = [
  'messages', 'user_profiles', 'message_edit_history', 'message_reactions', 'message_user_deletions',
  'message_recipient_status', 'call_participants', 'contact_reveal_audit', 'audit_logs', 'feedback_links',
  'installation_feedback', 'clients', 'migration_history'
];
async function snapshot(conn, label) {
  const [tables] = await conn.query(`SELECT TABLE_NAME, ENGINE, TABLE_COLLATION FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (${wantedTables.map(() => '?').join(',')}) ORDER BY TABLE_NAME`, wantedTables);
  const [columns] = await conn.query(`SELECT TABLE_NAME,COLUMN_NAME,COLUMN_TYPE,IS_NULLABLE,COLUMN_DEFAULT,CHARACTER_SET_NAME,COLLATION_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (${wantedTables.map(() => '?').join(',')}) ORDER BY TABLE_NAME,ORDINAL_POSITION`, wantedTables);
  const [indexes] = await conn.query(`SELECT TABLE_NAME,INDEX_NAME,COLUMN_NAME,NON_UNIQUE,SEQ_IN_INDEX FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (${wantedTables.map(() => '?').join(',')}) ORDER BY TABLE_NAME,INDEX_NAME,SEQ_IN_INDEX`, wantedTables);
  const output = { label, capturedAt: new Date().toISOString(), tables, columns, indexes };
  const file = path.join(process.cwd(), 'server', 'tmp', `local-db-chat-hotfix-${label}-${Date.now()}.json`);
  fs.writeFileSync(file, JSON.stringify(output, null, 2));
  return file;
}
async function tableExists(conn, table) {
  const [rows] = await conn.query('SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1', [table]);
  return rows.length > 0;
}
async function indexExists(conn, table, index) {
  const [rows] = await conn.query('SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1', [table, index]);
  return rows.length > 0;
}
async function addIndexIfMissing(conn, table, index, sql) {
  if (!(await tableExists(conn, table))) return { table, index, status: 'skipped_missing_table' };
  if (await indexExists(conn, table, index)) return { table, index, status: 'already_exists' };
  await conn.query(sql);
  return { table, index, status: 'created' };
}
async function run() {
  fs.mkdirSync(path.join(process.cwd(), 'server', 'tmp'), { recursive: true });
  const conn = await mysql.createConnection(config);
  const before = await snapshot(conn, 'before');
  const statements = [
    `SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS migration_history (
      migration_id VARCHAR(100) NOT NULL,
      description VARCHAR(255) NOT NULL,
      applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (migration_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS message_edit_history (
      id VARCHAR(36) NOT NULL,
      message_id VARCHAR(36) NOT NULL,
      edited_by VARCHAR(36) NULL,
      previous_content TEXT NULL,
      new_content_hash CHAR(64) NOT NULL,
      edited_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_message_edit_history_message (message_id,edited_at),
      INDEX idx_message_edit_history_user (edited_by),
      CONSTRAINT fk_message_edit_history_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
      CONSTRAINT fk_message_edit_history_user FOREIGN KEY (edited_by) REFERENCES user_profiles(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS message_reactions (
      id VARCHAR(36) NOT NULL,
      message_id VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NOT NULL,
      reaction_type ENUM('like','love','laugh','wow','sad','angry') NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_message_reaction_user (message_id,user_id),
      INDEX idx_message_reactions_user (user_id),
      CONSTRAINT fk_message_reactions_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
      CONSTRAINT fk_message_reactions_user FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS message_user_deletions (
      id VARCHAR(36) NOT NULL,
      message_id VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NOT NULL,
      deleted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_message_user_deletion (message_id,user_id),
      INDEX idx_message_user_deletions_user (user_id,deleted_at),
      CONSTRAINT fk_message_user_deletions_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
      CONSTRAINT fk_message_user_deletions_user FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS message_recipient_status (
      id VARCHAR(36) NOT NULL,
      message_id VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NOT NULL,
      delivered_at TIMESTAMP NULL,
      read_at TIMESTAMP NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uq_message_recipient_status (message_id,user_id),
      INDEX idx_message_recipient_status_user_read (user_id,read_at),
      CONSTRAINT fk_message_recipient_status_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
      CONSTRAINT fk_message_recipient_status_user FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS call_participants (
      id VARCHAR(36) NOT NULL,
      call_id VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NOT NULL,
      status ENUM('invited','ringing','accepted','declined','ended','missed') NOT NULL DEFAULT 'ringing',
      joined_at DATETIME NULL,
      left_at DATETIME NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_call_participant (call_id,user_id),
      INDEX idx_call_participants_user_status (user_id,status,created_at),
      CONSTRAINT fk_call_participants_call FOREIGN KEY (call_id) REFERENCES messages(id) ON DELETE CASCADE,
      CONSTRAINT fk_call_participants_user FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS contact_reveal_audit (
      id VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NULL,
      entity_type VARCHAR(50) NOT NULL,
      entity_id VARCHAR(36) NOT NULL,
      field_name VARCHAR(80) NOT NULL,
      reason VARCHAR(255) NULL,
      ip_address VARCHAR(64) NULL,
      user_agent VARCHAR(255) NULL,
      revealed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_contact_reveal_entity (entity_type,entity_id,revealed_at),
      INDEX idx_contact_reveal_user (user_id,revealed_at),
      CONSTRAINT fk_contact_reveal_user FOREIGN KEY (user_id) REFERENCES user_profiles(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  ];
  for (const sql of statements) await conn.query(sql);
  const indexResults = [];
  indexResults.push(await addIndexIfMissing(conn, 'messages', 'idx_messages_kind_created', 'ALTER TABLE messages ADD INDEX idx_messages_kind_created (message_kind, created_at)'));
  indexResults.push(await addIndexIfMissing(conn, 'messages', 'idx_messages_kind_call_status', 'ALTER TABLE messages ADD INDEX idx_messages_kind_call_status (message_kind, call_status, created_at)'));
  indexResults.push(await addIndexIfMissing(conn, 'feedback_links', 'idx_feedback_links_client_active', 'ALTER TABLE feedback_links ADD INDEX idx_feedback_links_client_active (client_id, installation_id, is_used, expires_at)'));
  indexResults.push(await addIndexIfMissing(conn, 'feedback_links', 'idx_feedback_links_token_expires', 'ALTER TABLE feedback_links ADD INDEX idx_feedback_links_token_expires (unique_token, expires_at)'));
  indexResults.push(await addIndexIfMissing(conn, 'installation_feedback', 'idx_installation_feedback_client_install', 'ALTER TABLE installation_feedback ADD INDEX idx_installation_feedback_client_install (client_id, installation_id, created_at)'));
  indexResults.push(await addIndexIfMissing(conn, 'clients', 'idx_clients_name_branch', 'ALTER TABLE clients ADD INDEX idx_clients_name_branch (client_name, branch)'));
  indexResults.push(await addIndexIfMissing(conn, 'user_profiles', 'idx_user_profiles_active_role', 'ALTER TABLE user_profiles ADD INDEX idx_user_profiles_active_role (is_active, role, created_at)'));
  await conn.query(`INSERT INTO migration_history (migration_id, description) VALUES
    ('20260710_chat_support_tables_hotfix', 'Local test hotfix: chat edit, reaction, deletion, recipient status tables'),
    ('20260710_calls_feedback_contact_performance', 'Local test hotfix: group call participants, contact reveal audit, feedback/performance indexes')
    ON DUPLICATE KEY UPDATE description = VALUES(description)`);
  const after = await snapshot(conn, 'after');
  const [tables] = await conn.query(`SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('message_edit_history','message_reactions','message_user_deletions','message_recipient_status','call_participants','contact_reveal_audit') ORDER BY TABLE_NAME`);
  const [indexes] = await conn.query(`SELECT TABLE_NAME,INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('message_recipient_status','call_participants','messages','feedback_links','installation_feedback','clients','user_profiles') ORDER BY TABLE_NAME,INDEX_NAME`);
  await conn.end();
  console.log(JSON.stringify({ before, after, tables: tables.map(row => row.TABLE_NAME), indexResults, indexCount: indexes.length }, null, 2));
}
run().catch(error => { console.error(error); process.exit(1); });
