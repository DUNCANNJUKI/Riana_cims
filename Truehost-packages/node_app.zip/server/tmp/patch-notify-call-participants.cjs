﻿const fs = require('fs');
const path = require('path');
const file = path.join(process.cwd(), 'server', 'index.js');
let source = fs.readFileSync(file, 'utf8');
if (source.includes('const notifyCallParticipants = async')) {
  console.log('notifyCallParticipants already exists');
  process.exit(0);
}
const pattern = /const notifyMessageParticipants = \(message, payload\) => \{\r?\n\s+if \(!message\) return;\r?\n\s+notifyChatClients\(message\.sender_id, payload\);\r?\n\s+notifyChatClients\(message\.receiver_id, payload\);\r?\n\};\r?\n/;
const match = source.match(pattern);
if (!match) throw new Error('notifyMessageParticipants block not found');
const helper = `${match[0]}
const notifyCallParticipants = async (callId, payload) => {
  const [callRows] = await pool.query('SELECT sender_id,receiver_id FROM messages WHERE id = ? LIMIT 1', [callId]);
  const call = callRows[0];
  if (!call) return;
  const [participantRows] = await pool.query('SELECT user_id FROM call_participants WHERE call_id = ?', [callId]);
  const participantIds = new Set(
    [call.sender_id, call.receiver_id, ...participantRows.map((row) => row.user_id)]
      .filter(Boolean)
      .map((value) => String(value)),
  );
  participantIds.forEach((userId) => notifyChatClients(userId, payload));
};
`;
source = source.replace(pattern, helper);
fs.writeFileSync(file, source, 'utf8');
console.log('added notifyCallParticipants helper');
