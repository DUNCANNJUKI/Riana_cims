module.exports = {
  apps: [{
    name: 'riana-cims',
    cwd: __dirname,
    script: 'server/index.js',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_memory_restart: '750M',
    env_production: { NODE_ENV: 'production', PORT: 8081 },
  }],
};
