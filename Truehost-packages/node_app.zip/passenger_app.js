const databaseAliases = {
  DATABASE_HOST: ['DB_HOST'],
  DATABASE_PORT: ['DB_PORT'],
  DATABASE_NAME: ['DB_NAME'],
  DATABASE_USER: ['DB_USER'],
  DATABASE_PASSWORD: ['DB_PASSWORD', 'DB_PASS'],
};

for (const [canonical, cpanelAliases] of Object.entries(databaseAliases)) {
  const configuredAlias = cpanelAliases.find((alias) => process.env[alias] !== undefined && process.env[alias] !== '');
  if (!process.env[canonical] && configuredAlias) {
    process.env[canonical] = process.env[configuredAlias];
  }
}

require('./server/index.js');
