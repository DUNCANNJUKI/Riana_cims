import{t as n}from"./format-DNQ09-IE.js";function s(e){const t=n(e),o=t.getMonth();return t.setFullYear(t.getFullYear(),o+1,0),t.setHours(23,59,59,999),t}export{s as e};
