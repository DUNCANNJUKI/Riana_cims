const e=()=>{const t=localStorage.getItem("riana_user");if(!t)return null;try{const r=JSON.parse(t);return r!=null&&r.id?r:null}catch{return null}};export{e as g};
